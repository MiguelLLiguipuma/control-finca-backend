import { query } from '../db/db.js';

export const CalendarioModel = {
	// 1. Obtener todos los calendarios
	findAll: () =>
		query(
			`SELECT c.id, c.semana, c.anio, ci.color, e.nombre AS empresa, c.estado
       FROM calendarios_enfunde c
       LEFT JOIN cintas ci ON ci.id = c.color_id
       LEFT JOIN empresas e ON e.id = c.empresa_id
       ORDER BY c.anio DESC, c.semana`,
		),

	// 2. Buscar por ID
	findById: (id) =>
		query(
			`SELECT c.*, ci.color, e.nombre AS empresa
       FROM calendarios_enfunde c
       LEFT JOIN cintas ci ON ci.id = c.color_id
       LEFT JOIN empresas e ON e.id = c.empresa_id
       WHERE c.id=$1`,
			[id],
		),

	// 3. Validar duplicados (Corregido: parámetro 'anio' y columna 'anio')
	findBySemanaAnioEmpresa: (semana, anio, empresa_id) =>
		query(
			`SELECT * FROM calendarios_enfunde 
       WHERE semana=$1 AND anio=$2 AND empresa_id=$3`,
			[semana, anio, empresa_id],
		),

	// 4. Crear (Corregido: nombre de columna y variable)
	create: ({ semana, anio, color_id, empresa_id, estado = true }) =>
		query(
			`INSERT INTO calendarios_enfunde (semana, anio, color_id, empresa_id, estado)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
			[semana, anio, color_id, empresa_id, estado],
		),

	// 5. Actualizar (Corregido: uso de COALESCE con la columna anio)
	update: (id, { semana, anio, color_id, empresa_id, estado }) =>
		query(
			`UPDATE calendarios_enfunde SET
         semana = COALESCE($1, semana),
         anio  = COALESCE($2, anio),
         color_id = COALESCE($3, color_id),
         empresa_id = COALESCE($4, empresa_id),
         estado = COALESCE($5, estado)
       WHERE id=$6 RETURNING *`,
			[
				semana ?? null,
				anio ?? null,
				color_id ?? null,
				empresa_id ?? null,
				estado ?? null,
				id,
			],
		),

	// 6. Eliminar
	remove: (id) => query('DELETE FROM calendarios_enfunde WHERE id=$1', [id]),
};
