import { CalendarioModel } from '../models/calendarioModel.js';
import { CintaModel } from '../models/cintaModel.js';
import { EmpresaModel } from '../models/empresaModel.js';

export const CalendarioService = {
	/* =============================
	   CONSULTAS
	============================= */
	getAll: async () => (await CalendarioModel.findAll()).rows,

	getById: async (id) => {
		const res = await CalendarioModel.findById(id);
		if (!res.rows.length) throw new Error('Calendario no encontrado');
		return res.rows[0];
	},

	/* =============================
	   CREAR CALENDARIO
	============================= */
	create: async (payload) => {
		const { semana, año, color_id, empresa_id, estado = true } = payload;

		if (!semana || !año || !color_id || !empresa_id) {
			throw new Error('semana, año, color_id y empresa_id son requeridos');
		}

		// Validar cinta
		const cinta = await CintaModel.findById(color_id);
		if (!cinta.rows.length) throw new Error('color_id no existe');

		// Validar empresa
		const emp = await EmpresaModel.findById(empresa_id);
		if (!emp.rows.length) throw new Error('empresa_id no existe');

		// Unicidad (semana, año, empresa)
		const dup = await CalendarioModel.findBySemanaAnioEmpresa(
			semana,
			año,
			empresa_id,
		);
		if (dup.rows.length) {
			throw new Error('Calendario duplicado para esa semana/año/empresa');
		}

		return (
			await CalendarioModel.create({
				semana,
				año,
				color_id,
				empresa_id,
				estado,
			})
		).rows[0];
	},

	/* =============================
	   ACTUALIZAR CALENDARIO
	============================= */
	update: async (id, payload) => {
		const cur = await CalendarioModel.findById(id);
		if (!cur.rows.length) throw new Error('Calendario no encontrado');

		if (payload.color_id) {
			const c = await CintaModel.findById(payload.color_id);
			if (!c.rows.length) throw new Error('color_id no existe');
		}

		if (payload.empresa_id) {
			const e = await EmpresaModel.findById(payload.empresa_id);
			if (!e.rows.length) throw new Error('empresa_id no existe');
		}

		return (await CalendarioModel.update(id, payload)).rows[0];
	},

	/* =============================
	   CERRAR / ABRIR CALENDARIO
	============================= */
	cerrarCalendario: async (id) => {
		const cal = await CalendarioModel.findById(id);
		if (!cal.rows.length) throw new Error('Calendario no encontrado');

		if (cal.rows[0].estado === false) {
			throw new Error('El calendario ya está cerrado');
		}

		return (await CalendarioModel.update(id, { estado: false })).rows[0];
	},

	activarCalendario: async (id) => {
		const cal = await CalendarioModel.findById(id);
		if (!cal.rows.length) throw new Error('Calendario no encontrado');

		return (await CalendarioModel.update(id, { estado: true })).rows[0];
	},

	/* =============================
	   ELIMINAR
	============================= */
	remove: async (id) => {
		await CalendarioModel.remove(id);
		return { ok: true };
	},
};
