import { CalendarioService } from '../services/calendarioService.js';

export const CalendarioController = {
	async list(_req, res) {
		try {
			res.json(await CalendarioService.getAll());
		} catch (e) {
			res.status(500).json({ error: e.message });
		}
	},

	async get(req, res) {
		try {
			const item = await CalendarioService.getById(req.params.id);
			if (!item)
				return res.status(404).json({ error: 'Calendario no encontrado' });
			res.json(item);
		} catch (e) {
			res.status(500).json({ error: e.message });
		}
	},

	async create(req, res) {
		try {
			/* Extraemos explícitamente para asegurar que si el frontend 
         comete un error y envía 'año', podamos manejarlo o mapearlo a 'anio'.
      */
			const { semana, anio, año, color_id, empresa_id } = req.body;

			const payload = {
				semana,
				anio: anio || año, // Soporte híbrido temporal por si el frontend falla
				color_id,
				empresa_id,
			};

			res.status(201).json(await CalendarioService.create(payload));
		} catch (e) {
			res.status(400).json({ error: e.message });
		}
	},

	async update(req, res) {
		try {
			const { semana, anio, año, color_id, empresa_id, estado } = req.body;

			const payload = {
				semana,
				anio: anio || año,
				color_id,
				empresa_id,
				estado,
			};

			res.json(await CalendarioService.update(req.params.id, payload));
		} catch (e) {
			res.status(400).json({ error: e.message });
		}
	},

	async remove(req, res) {
		try {
			res.json(await CalendarioService.remove(req.params.id));
		} catch (e) {
			res.status(400).json({ error: e.message });
		}
	},
};
