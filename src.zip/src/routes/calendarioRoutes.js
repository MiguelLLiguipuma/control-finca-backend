import { Router } from 'express';
import { CalendarioController } from '../controllers/calendarioController.js';

const router = Router();
router.get('/', CalendarioController.list);
router.get('/:id', CalendarioController.get);
router.post('/', CalendarioController.create);
router.put('/:id', CalendarioController.update);
router.delete('/:id', CalendarioController.remove);
export default router;
